package server_connections;

/**
 * Stores the username and password for the SQL server.
 *
 * @author Christopher Raleigh
 * @author Benjamin Ngo
 * @author Jeremy Wong
 * @author David-Eric Thorpe
 */
public class Credentials {

    /**
     * Change to actual username before building!
     *
     * @return our SQL username
     */
    static String getUsername() {
        return "gentlemen";
    }

    /**
     * Change to actual password before building!
     *
     * @return our SQL password
     */
    static String getPassword() {
        return "workhard";
    }
}
